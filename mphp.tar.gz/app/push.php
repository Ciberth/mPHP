<html>
<body>
	<form action="write.php" method="post">
        	<input type="text" name="name" id="name">
        	<input type="text" name="price" id="price">
		<input type="submit" name="btn" value="Submit">
	</form>
</body>
</html>

